## İstediğiniz gibi özelleştirip kullanabilirsiniz
## izinsiz paylaşılması yasaktır 

## discord.gg/vsc